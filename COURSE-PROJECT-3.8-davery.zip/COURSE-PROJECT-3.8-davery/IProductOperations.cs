//Interface Class
public interface IProductOperations
{
    void UpdateQuantity(int newQuantity);
    void UpdatePrice(float newPrice);
    void DisplayProductDetails();
}