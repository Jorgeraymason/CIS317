//Abstract Class
public abstract class ProductBase : IProductOperations
{
    private static int nextProductId = 1;

    protected int ProductId { get; }
    protected string Name { get; set; }
    protected int Quantity { get; set; }
    protected float Price { get; set; }

    public ProductBase(string name, int quantity, float price)
    {
        ProductId = nextProductId++;
        Name = name;
        Quantity = quantity;
        Price = price;
    }

    public void UpdateQuantity(int newQuantity)
    {
        Quantity = newQuantity;
    }

    public void UpdatePrice(float newPrice)
    {
        Price = newPrice;
    }

    public abstract void DisplayProductDetails();
}